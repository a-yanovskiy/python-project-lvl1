from brain_games.cli import welcome_user

def main():
	return 'Welcome to the Brain Games!\n'
print(main())
welcome_user()

if __name__ == '__main__':
	main()
	welcome_user()
